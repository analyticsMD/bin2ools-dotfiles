bin2ools-rds:  RDS connect tool.
