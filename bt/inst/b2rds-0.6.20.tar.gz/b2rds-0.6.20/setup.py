# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['b2rds', 'b2rds.gen', 'b2rds.poc', 'b2rds.poc.test']

package_data = \
{'': ['*'], 'b2rds': ['data/*', 'lib/*']}

install_requires = \
['poethepoet>=0.13.1,<0.14.0']

setup_kwargs = {
    'name': 'b2rds',
    'version': '0.6.20',
    'description': '',
    'long_description': 'bin2ools-rds:  RDS connect tool.\n',
    'author': 'Marc Anthony Slayton',
    'author_email': '4723322+gangofnuns@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
