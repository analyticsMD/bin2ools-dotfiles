#!/usr/bin/env python3.9

import os
import iterm2
#import pyobjc
import AppKit
import osascript

from sys import argv
cluster = argv[1]

#chain.echo(f"cluster: {cluster}\n\n\n*80=")
#async def main(connection):
#    window = app.current_window
#    if window is not None:
#        await window.async_create_tab()
#    else:
#        print("No current window")


# Launch the app
#async def main(connection):
iterm = AppKit.NSWorkspace.sharedWorkspace().launchApplication_("iTerm2")
app = iterm.async_get_app(cluster)

#ret_code,os.environ["ITERM2_COOKIE"],err = (
#    osascript.run('tell application "iTerm2" to request cookie'))

#if os.environ["ITERM2_COOKIE"]:
#    pass
#else:
#    print("Failed to get a cookie from iTerm")
#    print("ret_code: " + ret_code)
#    print ("err: " + err)


async def main(connection):
    app = await iterm.async_get_app(connection)
#    await app.async_activate()
    cmd = f"/Users/marc/local/bintools/cmd/rds demo-a-amd"
    await iterm.Window.async_create(connection, command=cmd)

iterm.run_until_complete(main, True)

