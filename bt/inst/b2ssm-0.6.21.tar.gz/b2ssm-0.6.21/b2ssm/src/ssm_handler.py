from b2ssm import ssm

handler = ssm.handler
