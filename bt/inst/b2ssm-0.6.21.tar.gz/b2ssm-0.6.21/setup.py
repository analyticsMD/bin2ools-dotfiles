# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['b2ssm', 'b2ssm.src']

package_data = \
{'': ['*'], 'b2ssm': ['data/json/aws/*', 'lib/*'], 'b2ssm.src': ['data/*']}

install_requires = \
['flake8>=4.0.1,<5.0.0']

setup_kwargs = {
    'name': 'b2ssm',
    'version': '0.6.21',
    'description': '',
    'long_description': '# bin2ools-ssm\n\n# Making life with AWS SSO a little easier\n',
    'author': 'Marc Anthony Slayton',
    'author_email': '4723322+gangofnuns@users.noreply.github.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
