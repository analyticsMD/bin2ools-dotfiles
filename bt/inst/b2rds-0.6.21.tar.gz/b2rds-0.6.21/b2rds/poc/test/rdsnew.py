#!/usr/bin/env python3

import os
import click
from click.shell_completion import CompletionItem


#@click.group()
#def cli():
#    pass

@click.command()
@click.argument('cluster', default='demo-a-amd')
def rds(cluster):
    """Process command line arguments."""
    if cluster == '':
        args = sys.argv[1:]
        cluster = args[0]
    click.echo(f"logging into... {cluster}")
    click.launch(demo-a-amd")

#@cli.command("sub2")
#def sub2():
#    print("sub2")

if __name__ == "__main__":
   rds()


