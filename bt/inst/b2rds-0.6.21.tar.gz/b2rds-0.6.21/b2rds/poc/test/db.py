#!/usr/bin/env python

'''Run the rds connector tool.'''

import os
import sys
import iterm2
import osascript
from AppKit import NSWorkspace

def launch(args=sys.argv):
    '''
    Secured version of iTerm wrapper.
    1.) Launch iTerm and get a security token.
    2.) Store the token from iTerm in $ITERM_COOKIE env variable.
    Required to exec the iterm API without a "Do you trust this program?" dialog box.
    See https://gitlab.com/gnachman/iterm2/-/wikis/iTerm2-Version-3.3-Security-Updates
    '''
    iterm = NSWorkspace.sharedWorkspace().launchApplication_("iTerm")
    if not iterm:
        print("Failed to launch iTerm2")
        return False

    ret_code,os.environ["ITERM2_COOKIE"],err = (
        osascript.run('tell application "iTerm2" to request cookie'))

    if os.environ["ITERM2_COOKIE"]:
        return True
    else:
        print("Failed to get a cookie from iTerm")
        print("ret_code: " + ret_code)
        print ("err: " + err)
        return False

async def db_connect(connection):
    '''Connect to iTerm2 and upgrade brew casks.'''
    from sys import argv as args
    if not args[1]:
        return False

    cmd = f"~/local/bintools/cmd/rds {args[1]}\n"
    # connect to iTerm
    app = await iterm2.async_get_app(connection)

    # vertical split in terminal session.
    session = app.current_terminal_window.current_tab.current_session
    await session.async_split_pane(vertical=True)

    # run the wrapped tool in the new pane.
    new_session = app.current_terminal_window.current_tab.current_session
    await new_session.async_send_text(cmd)

    # return focus to the original pane.
    await session.async_activate()

    return True

if __name__ == '__main__':
    if launch():
        # Passing True for the second parameter means keep trying to
        # connect until the app launches.
        iterm2.run_until_complete(db_connect, True, True)
