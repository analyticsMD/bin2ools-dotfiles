import click

import importlib.metadata
__version__ = importlib.metadata.version("b2rds")

@click.command()
@click.option
def rds(args=None):
    """Process command line arguments."""
    if not args:
        args = sys.argv[1:]
    tz = args[0]
    print(greet(tz))


