__version__ = '0.6.16'
__import__('pkg_resources').declare_namespace(__name__)

